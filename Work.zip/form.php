<link href="/css/bootstrap.min.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<div class="container p-5 my-5 border">
<?php

require_once ('config.php');

if(isset($_GET['formsubmit'])) echo "<script>alert('Форма отправлена!');</script>";

// SQL-запрос для выборки данных
$sql = "SELECT * FROM employee";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Управление записями</title>
</head>
<body>
    <h1>Список сотрудников</h1>

    <!-- Форма для добавления новой записи -->
    <form method="post"  action="add_in_table.php">
        <label for="Name">Имя</label>
        <input type="text" class="form-control" id="Name" name="Name" required>
        <br>
        <label for="Familiya">Фамилия</label>
        <input type="Familiya" class="form-control" id="Familiya" name="Familiya" required>
        <br>
        <label for="Otchestvo">Пароль</label>
        <input type="text" class="form-control" id="Otchestvo" name="Otchestvo" required>
        <br>
        <button type="submit" class="btn btn-primary" name="add">Добавить</button>
        <br><br>
    </form>

    <?php
    // Подключение к базе данных
    require_once ('config.php');

    // Обработка отправленной формы
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
        $Name = mysqli_real_escape_string($conn, $_POST['Name']);
        $Familiya = mysqli_real_escape_string($conn, $_POST['Familiya']);
        $Otchestvo = mysqli_real_escape_string($conn, $_POST['Otchestvo']);

        // Запрос на добавление данных
        $sql = "INSERT INTO employees
    (Name, Familiya, Otchestvo) VALUES ('$Name', '$Familiya', '$Otchestvo')";
        if (mysqli_query($conn, $sql)) {
            echo "<p>Новая запись успешно добавлена!</p>";
            header('Refresh: 3; URL=/form.php');
        } else {
            echo "<p>Ошибка: " . mysqli_error($conn) . "</p>";
        }
    }

    // Обработка удаления записи
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        
        $sql = "DELETE FROM employees
 WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            echo "<p>Запись успешно удалена!</p>";
            header('Refresh: 3; URL=/form.php');
        } else {
            echo "<p>Ошибка при удалении: " . mysqli_error($conn) . "</p>";
        }
    }

    if (isset($_POST['edit_id'])) {
        $edit_id = (int)$_POST['edit_id'];
        
        // Запрос на выборку данных для редактирования
        $sql = "SELECT * FROM employees
 WHERE id = $edit_id";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
        $edit_id = (int)$_POST['edit_id'];
        $Name = mysqli_real_escape_string($conn, $_POST['Name']);
        $Familiya = mysqli_real_escape_string($conn, $_POST['Familiya']);
        $Otchestvo = mysqli_real_escape_string($conn, $_POST['Otchestvo']);
    
        // Запрос на обновление данных
        $sql = "UPDATE employees
 SET Name = '$Name', Familiya = '$Familiya', Otchestvo = '$Otchestvo' WHERE id = $edit_id";
        
        if (mysqli_query($conn, $sql)) {
            echo "<p>Запись успешно обновлена!</p>";
            header('Refresh: 3; URL=/form.php');
        } else {
            echo "<p>Ошибка: " . mysqli_error($conn) . "</p>";
        }
    }

    ?>

    <!-- Форма для редактирования записи -->
    <?php if (isset($row)): ?>
    <h2>Редактировать запись</h2>
    <form method="post" action="edit_in_table.php">
        <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
        
        <label for="Name">Имя</label>
        <input type="text" class="form-control" id="Name" name="Name" value="<?php echo $row['Name']; ?>" required>
        <br>

        <label for="Familiya">Фамилия</label>
        <input type="Familiya" class="form-control" id="Familiya" name="Familiya" value="<?php echo $row['Familiya']; ?>" required>
        <br>

        <label for="Otchestvo">Отчество</label>
        <input type="text" class="form-control" id="Otchestvo" name="Otchestvo" value="<?php echo $row['Otchestvo']; ?>" required>
        <br>

        <button type="submit" class="btn btn-primary" name="update">Обновить</button>
        <br><br>
    </form>
    <?php endif; ?>
    
    <?php
    // Вывод таблицы с данными
    $sql = "SELECT * FROM employees";
    $result = mysqli_query($conn, $sql);
    ?>

    <!-- Таблица с данными -->
    <table border="1" class="table table-striped">
        <tr>
            <th>ID</th>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Отчество</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['Name'] . "</td>";
                echo "<td>" . $row['Familiya'] . "</td>";
                echo "<td>";
                echo "<form method='post' action='' style='display:inline;'>";
                echo "<input type='hidden' name='delete_id' value='" . $row['id'] . "'>";
                echo "<button type='submit' class='btn btn-primary' >Удалить</button>";
                echo "</form>";
                echo "<br>";
                echo "&nbsp;";
                echo "<form method='post' action=''>";
                echo "<input type='hidden' name='edit_id' value='" . $row['id'] . "'>";
                echo "<button type='submit' class='btn btn-primary' >Редактировать</button>";
                echo "</form>"; 
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Нет данных</td></tr>";
        }
        ?>
    </table>

    <?php
    // Закрытие подключения к базе данных
    mysqli_close($conn);
    ?>
</div>
</body>
</html>