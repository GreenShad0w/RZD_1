<?php
// Подключение к базе данных PostgreSQL
$conn = pg_connect("host=localhost dbname=RZD_1 user=postgres password=Z040602228");
if (!$conn) {
    die("Ошибка подключения к базе данных.");
}

// Получение данных из POST-запроса и экранирование
$full_name = pg_escape_string($conn, $_POST['full_name']);
$email = pg_escape_string($conn, $_POST['email']);
$espp_username = pg_escape_string($conn, $_POST['espp_username']);
$city_id = pg_escape_string($conn, $_POST['city_id']);
$curator_email = pg_escape_string($conn, $_POST['curator_email']);
$railway_id = pg_escape_string($conn, $_POST['railway_id']);
$shift_work = pg_escape_string($conn, $_POST['shift_work']);

$schedule_id = $_POST['schedule_id'];
$new_schedule_name = $_POST['new_schedule_name'];

if ($schedule_id === 'new' && !empty($new_schedule_name)) {
    // Проверка существования графика с таким названием
    $check_schedule = pg_query($conn, "SELECT id FROM schedules WHERE schedule_name = '$new_schedule_name'");
    if (pg_num_rows($check_schedule) > 0) {
        die("График с таким названием уже существует.");
    }
    
    // Вставка нового графика и его деталей с помощью CTE
    $sql = <<<SQL
    WITH new_schedule AS (
        INSERT INTO schedules (schedule_name)
        VALUES ('$new_schedule_name')
        RETURNING id
    )
    INSERT INTO schedule_details (schedule_id, day_of_week, start_time, end_time, lunch_start, lunch_end)
    SELECT ns.id, 
           day_of_week::week_day, 
           start_time::time, 
           end_time::time, 
           lunch_start::time, 
           lunch_end::time
    FROM new_schedule ns,
         (VALUES 
            ('Понедельник'::week_day, '09:00'::time, '18:00'::time, '13:00'::time, '14:00'::time),
            ('Вторник'::week_day, '09:00'::time, '18:00'::time, '13:00'::time, '14:00'::time),
            ('Среда'::week_day, '09:00'::time, '18:00'::time, '13:00'::time, '14:00'::time),
            ('Четверг'::week_day, '09:00'::time, '18:00'::time, '13:00'::time, '14:00'::time),
            ('Пятница'::week_day, '09:00'::time, '18:00'::time, '13:00'::time, '14:00'::time)
         ) AS days(day_of_week, start_time, end_time, lunch_start, lunch_end);
    SQL;
    
    $insert_schedule = pg_query($conn, $sql);
    if (!$insert_schedule) {
        die("Ошибка при создании нового графика и его деталей.");
    }
    
    // Получение id только что созданного графика
    $schedule_id_query = pg_query($conn, "SELECT id FROM schedules WHERE schedule_name = '$new_schedule_name'");
    if (!$schedule_id_query) {
        die("Ошибка при получении ID нового графика.");
    }
    $schedule_row = pg_fetch_assoc($schedule_id_query);
    $schedule_id = $schedule_row['id'];
    
} elseif ($schedule_id === 'new' && empty($new_schedule_name)) {
    die("Пожалуйста, введите название нового графика.");
}

// Вставка новой записи в таблицу employees
$insert_employee = pg_query($conn, "INSERT INTO employees (full_name, email, espp_username, city_id, schedule_id, curator_email, railway_id, shift_work) 
                                    VALUES ('$full_name', '$email', '$espp_username', '$city_id', '$schedule_id', '$curator_email', '$railway_id', '$shift_work')");
if (!$insert_employee) {
    die("Ошибка при добавлении записи.");
} else {
    echo "Запись успешно добавлена.";
}

// Закрытие соединения с базой данных
pg_close($conn);
?>