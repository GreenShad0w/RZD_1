<!DOCTYPE html>
<html lang="en">
<link href="/css/bootstrap.min.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<div class="container p-5 my-5 border">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- Форма для добавления новой записи
    <form method="post"  action="add_in_table.php">
        <label for="shedule_id">ID Графика (schedule_id)</label>
        <input type="text" class="form-control" id="schedule_id" name="schedule_id" required>
        <br>
        <button type="submit" class="btn btn-primary" name="add">Добавить</button>
        <br><br>
    </form>
-->
    <form method="post" action="employees.php">
    <button type="submit" class="btn btn-primary">Employees table</button>
    </form>

    <h2>Графики</h2>

    <?php
    $conn = pg_connect("host=localhost dbname=RZD_1 user=postgres password=Z040602228");
    if (!$conn) {
        echo "Error.<br>";
        exit;
    }

    $result = pg_query($conn, "SELECT * FROM schedule_details");
    if (!$result) {
        echo "Error code:2<br>";
        exit;
    }
    ?>

    <table border="1" class="table table-striped">
        <tr>
            <th>ID</th>
            <th>schedule_id</th>
            <th>День недели</th>
            <th>Начало дня</th>
            <th>Конец дня</th>
            <th>Начало обеда</th>
            <th>Конец обеда</th>
        </tr>
        <?php
        if (pg_num_rows($result) > 0) {
            while ($row = pg_fetch_assoc($result)) 
            {
                echo "
                <tr>
                    <td>{$row['id']}</td>
                    <td>{$row['schedule_id']}</td>
                    <td>{$row['day_of_week']}</td>
                    <td>{$row['start_time']}</td>
                    <td>{$row['end_time']}</td>
                    <td>{$row['lunch_start']}</td>
                    <td>{$row['lunch_end']}</td>
                </tr>
                ";
            }
        }
        ?>
    <?php
    $result = pg_query($conn, "SELECT * FROM schedules");
    if (!$result) {
        echo "Error code:2<br>";
        exit;
    }
    ?>

    <table border="1" class="table table-striped">
        <tr>
            <th>ID</th>
            <th>Название графика</th>
        </tr>
        <?php
        if (pg_num_rows($result) > 0) {
            while ($row = pg_fetch_assoc($result)) 
            {
                echo "
                <tr>
                    <td>{$row['id']}</td>
                    <td>{$row['schedule_name']}</td>
                </tr>
                ";
            }
        }
        ?>

    </table>
    </div>
</body>
</html>