<?php
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

// Загрузка Excel-файла
$spreadsheet = IOFactory::load('C:/Employees.xlsx');
$sheet = $spreadsheet->getActiveSheet();

// Подключение к базе данных PostgreSQL
$dsn = 'pgsql:host=localhost;dbname=RZD_1';
$username = 'postgres';
$password = 'Z040602228';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Подготовка SQL-запроса для вставки данных
$sql = "INSERT INTO employees (full_name, email, espp_username) VALUES (:full_name, :email, :espp_username)";
$stmt = $pdo->prepare($sql);

// Чтение данных из Excel и вставка в базу данных
$rowIterator = $sheet->getRowIterator();
$rowNumber = 1;
foreach ($rowIterator as $row) {
    if ($rowNumber == 1) { // Пропустить заголовок
        $rowNumber++;
        continue;
    }

    $cellIterator = $row->getCellIterator();
    $cellIterator->setIterateOnlyExistingCells(FALSE);

    $full_name = '';
    $espp_username = '';
    $email = '';

    $column = 1;
    foreach ($cellIterator as $cell) {
        switch ($column) {
            case 1:
                $full_name = $cell->getValue();
                break;
            case 2:
                $espp_username = $cell->getValue();
                break;
            case 3:
                $email = $cell->getValue();
                break;
        }
        $column++;
    }

    // Вставка в базу данных
    $stmt->bindParam(':full_name', $full_name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':espp_username', $espp_username);
    $stmt->execute();

    $rowNumber++;
}

echo "Вставка данных успешно завершена.";
?>