<!DOCTYPE html>
<html lang="en">
<link href="/css/bootstrap.min.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<div class="container p-5 my-5 border">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <?php

        $conn = pg_connect("host=localhost dbname=RZD_1 user=postgres password=Z040602228");
        if (!$conn) {
            echo "Ошибка подключения к базе данных.<br>";
            exit;
        }

        // Получаем данные из таблицы schedule
        $schedule_query = pg_query($conn, "SELECT id, schedule_name FROM schedules");
        if (!$schedule_query) {
            echo "Ошибка при выполнении запроса к таблице schedule.<br>";
            exit;
        }
        ?>

    <!-- Форма для добавления новой записи -->
    <form method="post"  action="add_in_table.php">
    <label for="full_name">ФИО</label>
    <input type="text" class="form-control" id="full_name" name="full_name" required>
    <br>
    <label for="email">Email</label>
    <input type="text" class="form-control" id="email" name="email" required>
    <br>
    <label for="espp_username">Учетная запись АСУ ЕСПП</label>
    <input type="text" class="form-control" id="espp_username" name="espp_username" required>
    <br>
    <label for="city_id">Город</label>
    <input type="text" class="form-control" id="city_id" name="city_id">
    <br>
    <label for="schedule_id">График</label>
    <select class="form-control" id="schedule_id" name="schedule_id" required>
        <option value="">Выберите график</option>
        <?php
            while ($schedule_row = pg_fetch_assoc($schedule_query)) {
                echo "<option value='" . $schedule_row['id'] . "'>" . $schedule_row['schedule_name'] . "</option>";
            }
        ?>
        <option value="new">Создать новый график</option>
    </select>
    <div id="new-schedule-field" style="display:none;">
        <label for="new_schedule_name">Название нового графика</label>
        <input type="text" class="form-control" id="new_schedule_name" name="new_schedule_name">
    </div>
    <br>
    <label for="curator_email">Почта Куратора</label>
    <input type="text" class="form-control" id="curator_email" name="curator_email" required>
    <br>
    <label for="railway_id">Дорога</label>
    <input type="text" class="form-control" id="railway_id" name="railway_id" required>
    <br>
    <label for="shift_work">Сменный сотрудник (true либо пусто)</label>
    <input type="text" class="form-control" id="shift_work" name="shift_work">
    <br>
    <button type="submit" class="btn btn-primary" name="add">Добавить</button>
    <br><br>
    </form>

    <script>
    document.getElementById('schedule_id').addEventListener('change', function() {
        if (this.value === 'new') {
            document.getElementById('new-schedule-field').style.display = 'block';
        } else {
            document.getElementById('new-schedule-field').style.display = 'none';
        }
    });
    </script>

    <form method="post" action="index.php">
    <button type="submit" class="btn btn-primary">Schedule tables</button>
    </form>
    <br>
    <form method="post" action="excel_work.php">
    <button type="submit" class="btn btn-primary">Excel</button>
    </form>

    <h2>БД сотрудников</h2>

    <?php

    $result = pg_query($conn, "SELECT * FROM employees");
    if (!$result) {
        echo "Error code:2<br>";
        exit;
    }
    ?>

    <table border="1" class="table table-striped">
        <tr>
            <th>ID</th>
            <th>ФИО</th>
            <th>Email</th>
            <th>Учетная запись АСУ ЕСПП</th>
            <th>Город</th>
            <th>График</th>
            <th>Почта Куратора</th>
            <th>Дорога</th>
            <th>Сменный сотрудник</th>
        </tr>
        <?php
        if (pg_num_rows($result) > 0) {
            while ($row = pg_fetch_assoc($result)) 
            {
                echo "
                <tr>
                    <td>{$row['id']}</td>
                    <td>{$row['full_name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['espp_username']}</td>
                    <td>{$row['city_id']}</td>
                    <td>{$row['schedule_id']}</td>
                    <td>{$row['curator_email']}</td>
                    <td>{$row['railway_id']}</td>
                    <td>{$row['shift_work']}</td>
                </tr>
                ";
            }
        }
        ?>
    </table>
    </div>
</body>
</html>